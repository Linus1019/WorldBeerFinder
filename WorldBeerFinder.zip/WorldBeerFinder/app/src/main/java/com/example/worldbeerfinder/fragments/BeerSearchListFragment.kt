package com.example.worldbeerfinder.fragments

import androidx.fragment.app.Fragment

class BeerSearchListFragment: Fragment() {
}