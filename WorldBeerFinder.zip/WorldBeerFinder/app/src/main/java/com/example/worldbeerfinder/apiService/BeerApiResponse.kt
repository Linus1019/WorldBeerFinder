package com.example.worldbeerfinder.apiService

import com.google.gson.annotations.SerializedName

class BeerApiResponse {
    @SerializedName("beer_name")
    val beerName: String? = null

    @SerializedName("image_url")
    val imageUrl: String? = null
}