package com.example.worldbeerfinder.apiService

import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Call
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Path

interface BeerApi {
    @GET("beers?{page}/{per_page}")
    fun getAllBeerList(
        @Path("page") page: Int = 1,
        @Path("per_page") perPage: Int = 10
    ) : Call<BeerApiResponse>

    companion object {
        val baseUrl = "https://punkapi.com/documentation/v2/"

        private val httpClient = OkHttpClient()
            .newBuilder()
            .addInterceptor(HttpLoggingInterceptor())
            .build()

        val client = Retrofit.Builder().baseUrl(baseUrl)
            .addConverterFactory(GsonConverterFactory.create())
            .client(httpClient)
            .build()
    }
}