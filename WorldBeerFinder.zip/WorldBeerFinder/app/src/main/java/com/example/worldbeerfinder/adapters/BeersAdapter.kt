package com.example.worldbeerfinder.adapters

class BeersAdapter : RecyclerView.Adapter {
}