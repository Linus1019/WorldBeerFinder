package com.example.worldbeerfinder.viewModels

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.worldbeerfinder.apiService.BeerApi
import com.example.worldbeerfinder.apiService.BeerApiResponse
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainViewModel: ViewModel() {
    enum class ErrorCode {
        NONE,
        INPUT_ERROR,
        API_ERROR
    }

    init {
        viewModelScope.launch {
            BeerApi.client.create(BeerApi::class.java)
                .getAllBeerList(0, 10).enqueue(object: Callback<BeerApiResponse> {
                    override fun onResponse(
                        call: Call<BeerApiResponse>,
                        response: Response<BeerApiResponse>
                    ) {
                        val response = response.body()
                    }

                    override fun onFailure(call: Call<BeerApiResponse>, t: Throwable) {

                    }
                })
        }
    }
}